const section = document.getElementById('section');
const head = document.getElementById('head');
const fullTipBox = document.getElementsByClassName('full-tip-box')[0];//新建文件夹成功的弹框
let iH = window.innerHeight;
const headH = head.offsetHeight;
section.style.height = iH - headH + 'px';

//页面缩放的时候计算section的高度
window.onresize = function(){
    iH = window.innerHeight;
    section.style.height = iH - headH + 'px';
}

let { startMove} = myTools;
function fullbox(val) {
    fullTipBox.innerHTML = `
    <span class="full-tip">
    <span class="inner">
        <span class="tip-text">${val}</span>
    </span>
    </span>`;
    startMove({
        obj: fullTipBox,
        json: {
            top: 0
        },
        durtion: 500,
        fx: 'bounceOut',
        cb() {
            setTimeout(() => {
                startMove({
                    obj: fullTipBox,
                    json: {
                        top: -40
                    },
                    durtion: 300
                })
            }, 1000);
        }
    });
}
