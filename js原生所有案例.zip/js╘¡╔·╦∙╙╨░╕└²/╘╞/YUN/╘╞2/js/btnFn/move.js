const ok = modelTree.getElementsByClassName('ok')[0];
const folderName = document.getElementsByClassName('folderName')[0];
const iconclose = document.getElementsByClassName('icon_close')[0];
const cancel = document.getElementsByClassName('cancel')[0];
let kid = 0;
remove.onclick = function(){
    if(!seleEleArr.length){
        fullbox('请选择想移动的文件')
    }else{
        modelTree.style.display = 'block';//出现移动的弹框
        content.appendChild(renderTree2(-1,-1));
    }
}
//移动的时候
ok.onclick = function(){//点击确认的时候
    log(kid,seleEleArr);
    if(seleEleArr.length){       
        /* 
            把选中的文件夹和他们下面的子级或孙子级都提取出来
            放到一个数组(children)中
            [我的音乐,周杰伦,发如雪,稻香,夜曲,王杰,张国荣]
        */
        seleEleArr.forEach(e=>{
            children.push(e);
            getChildren(e.id);
        });
        /* 
            如果提取出来的数组中的某个数据，包含kid，说明用户把
            选中的文件夹放到了自己或者自己的肚子里去了
            如果没有包含kid说明操作符合逻辑，就应该移动文件夹
        */
        if(!children.some(e=>e.id == kid)){//没有往自己移动的时候
            seleEleArr.forEach(e=>{
                let arr = getChild(kid);
                if(arr.some(ele=>ele.title === e.title)){
                    let a = arr.filter(f=>{
                        let re = new RegExp('^'+e.title+'(-副本)*$');
                        // log(re.test(f.title));
                        return re.test(f.title);
                    }).sort((a,b)=>{
                        return a.title.length - b.title.length;
                    });

                    if(a.length == 1){
                        e.title = a[0].title + '-副本';
                    }else{
                        e.title = a[a.length-1].title + '-副本';
                    }
                }
                e.pid = kid;
                e.checked = false;
            });
            render(breadNav.getElementsByTagName('span')[0].dataset.id*1);
            treeMenu.appendChild(renderTree(-1,-1));
        }else{
         fullbox('请重新选择');
        }
        children.length = 0;
        modelTree.style.display = 'none';
    }
}
cancel.onclick=iconclose.onclick=function(){
    modelTree.style.display = 'none';
}
function renderTree2(pid,num){//生成移动文件夹里目录
    content.innerHTML = '';
    let arr = getChild(pid);
    let ul = document.createElement('ul');;
    num++;
    ul.style.paddingLeft = num*5 + "px";
    arr && arr.forEach(e=>{
        let ary = getChild(e.id);
        let li = document.createElement('li');
        li.onclick = function(ev){
            let lis = content.getElementsByTagName('li');
            for(let i=0;i<lis.length;i++){
                lis[i].children[0].style.background = '';
            }
            li.children[0].style.background = '#999';
            //记录把选中的数据放到哪个数据下
            kid = e.id;
            log(data[kid].title)
            folderName.innerHTML =data[kid].title;
            ev.cancelBubble = true;
        }
        let div = document.createElement('div');
        div.className = `tree-title ${ary?'tree-ico':''} close`;
        let span = document.createElement('span');
        span.className = `${ary?'open':''}`;
        span.innerHTML = '<i></i>'+ e.title;
        div.appendChild(span);
        li.appendChild(div);
        if(ary){
            li.appendChild(renderTree2(e.id,num));
        }
        ul.appendChild(li);
    });
    return ul;
}


