const tanbox = document.getElementById('tanbox');
const aa = tanbox.getElementsByTagName('a');
const x = document.getElementsByClassName('close-ico')[0];
del.onclick = function () {//删除
    if (seleEleArr.length) {
        tanbox.style.display = 'block';
        aa[0].onclick = function () {
            seleEleArr.forEach(e => {
                if ('create' in data[e.id]) {
                    delete data[data[e.id].pid].num[data[e.id].create];
                }
                delete data[e.id];
            });
            render(breadNav.getElementsByTagName('span')[0].dataset.id * 1);
            // treeMenu.innerHTML = renderTree(-1,-1);
            treeMenu.appendChild(renderTree(-1, -1));
            tanbox.style.display = 'none';
        }
        aa[1].onclick = x.onclick = function () {
            tanbox.style.display = 'none';
        }
    } else {
        fullbox('没有选');
    }
}
document.onkeydown = function (ev) {
    if (ev.ctrlKey && ev.keyCode == 68) {
        del.onclick();
        ev.returnValue = false;
    } else {
        ev.returnValue = true;
    }
}

