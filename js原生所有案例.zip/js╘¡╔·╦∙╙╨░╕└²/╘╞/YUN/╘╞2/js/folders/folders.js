const folderBox = document.getElementsByClassName('folder-content')[0];
const folders = folderBox.getElementsByClassName('folders')[0];
const breadmenu = folderBox.getElementsByClassName('breadmenu')[0];
const breadNav = folderBox.getElementsByClassName('bread-nav')[0];
const fEmpty = folderBox.getElementsByClassName('f-empty')[0];  
const modelTree = document.getElementsByClassName('modal-tree')[0];
const content = modelTree.getElementsByClassName('content')[0];
const kuang =document.getElementsByClassName('kuang')[0];

let seleEleArr = [];//存储数组
const {getChild,addAttr,getParent,getParents,parentArr,targetP} = myTools;//解构对象
const {log,dir} = console;//方便打印 

addAttr('num',[]); //给数据添加属性num，默认为[]

function render(id){
    folders.innerHTML = '';//只要render就把数据清空    
    seleEleArr.length = 0;  //有没有子级，没有子级就把暂无文件元素打开
    let arr = getChild(id);  
    //log(arr);
    if(!arr){ //没有子级的时候
        fEmpty.style.display = 'block';
        checkedAll.className = '';
    }else{
        checkedAll.className = arr.every(e=>e.checked)?'checked':'';//每项都选中的时候全选被选中
        fEmpty.style.display = 'none';
        arr.forEach((e,k) => {
            if(e.checked){seleEleArr.push(e);} //捕获被选中的数据
            let div = document.createElement('div'); //文件夹的盒子
            div.className = e.checked?'file-item active':'file-item';
            div.dataset.id = e.id;
            let img = new Image();//新建图片的另一种方式
            img.src = 'img/folder-b.png';
            img.ondblclick = function(){
                render(e.id);
                renderMenu(e.id);              
                arr.forEach(e=>e.checked=false);//需要清除这些元素选中的样式
            }        
            let span = document.createElement('span');  //放文件名字的容器
            span.className = 'folder-name';
            span.innerHTML = e.title;
    
            let input = document.createElement('input');
            input.type = 'text';
            input.className = 'editor';
            input.value = e.title;
           
            let i = document.createElement('i'); //是否选中
            i.className = e.checked?'checked':'';
            i.onclick = function(){
                e.checked = !e.checked;
                //log(id,e.id);
                render(id);
            }
            div.appendChild(img);
            div.appendChild(span);
            div.appendChild(input);
            div.appendChild(i);
            folders.appendChild(div);
        });
    }
}
render(0);

log(data);
checkedAll.onclick = function(){//全选
    //获取span的id
    let id = breadNav.getElementsByTagName('span')[0].dataset.id*1;
    //通过获取的id去找这个id下的子级数据
    let arr = getChild(id);
    this.classList.toggle('checked'); //点的时候切换checked

    //循环子级数据，把子级数据的checked变成和checkall的class一致的布尔值
    arr && arr.forEach(e=>{
        e.checked = this.classList.contains('checked');
    });
    //因为上面的代码已经把数据给变了，所以render之后，页面的展示效果跟数据走
    render(id);
}
