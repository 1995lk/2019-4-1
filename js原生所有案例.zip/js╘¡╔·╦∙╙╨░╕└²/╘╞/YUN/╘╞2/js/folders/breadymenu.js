function renderMenu(id) {//面包屑
    breadNav.innerHTML = '';
    let arr = getParents(id); //找到一堆父级数据
    let arr2 = getChild(id);//找一级儿子  
    if (arr) {//有父级数据的情况下
        arr.forEach((e, i, all) => {//循环父级数据
            if (i != all.length - 1) {//索引不等于最后一项索引的时候
                let a = document.createElement('a');//创建a元素
                a.href = 'javascript:;';
                a.innerHTML = e.title;//父级数据的title
                a.onclick = function () {
                    arr2 && arr2.forEach(e => e.checked = false);//如果有子集数据 把子集数据的checked取消
                    log(e.id)
                    render(e.id);
                    renderMenu(e.id);
                }
                breadNav.appendChild(a);
            } else {//即微云的时候
                let span = document.createElement('span');
                span.innerHTML = e.title;
                span.dataset.id = e.id;
                breadNav.appendChild(span);
            }
        })
    }
}
renderMenu(0);

