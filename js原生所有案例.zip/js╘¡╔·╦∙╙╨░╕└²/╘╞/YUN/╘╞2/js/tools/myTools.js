let myTools = (function(){
    /*
        通过父级的id获取子级
    */
    let children = [];
    function getChild(pid){
        // if(!data[pid])return null;  //先看当前这个数据有没有，没有直接返回一个null
        let arr = [];
        let onOff = false;
        for(let attr in data){
            if(data[attr].pid === pid){
                arr.push(data[attr]);
                onOff = true;
            }
        }
        if(onOff){
            return arr;
        }else{
            return null;
        }
    }

    function getChildren(pid){
        let arr = getChild(pid);  //有子级
        arr && arr.forEach(e=>{
            children.push(e);
            getChildren(e.id);
        });
    }

    //通过id找pid
    function getParent(id){
        if(!data[id] || data[id].pid ==-1)return null;
        return data[data[id].pid];  
    }

    function getParents(id){ //找父级的父级
        let parentArr = [];
        let now = data[id]; //当前的id  [3]
        while(now){//0
            parentArr.unshift(now);// [0,2,3]
            now = getParent(now.id);//null
        }
        return parentArr;
    }
    function addAttr(attr,value){
        for(let k in data){
            if(Array.isArray(value)){
                data[k][attr] = [];
            }else{
                data[k][attr] = value;
            }
           
        }
    }

    function targetP(ele,cName){
        if(ele.classList.contains(cName)){
            return true;
        }
        return ele.parentNode.classList.contains(cName);
    }

    function duang(obj1,obj2){
        let l1 = obj1.offsetLeft;
        let t1 = obj1.offsetTop;
        let b1 = t1 + obj1.offsetHeight;
        let r1 = l1 + obj1.offsetWidth;

        let l2 = obj2.offsetLeft;
        let t2 = obj2.offsetTop - folders.scrollTop;
        let b2 = t2 + obj2.offsetHeight;
        let r2 = l2 + obj2.offsetWidth;

        if(r1<l2 || b1 < t2 || l1 > r2 || t1 > b2){
            return false;
        }else{
            return true;
        }
    }
    function startMove(opts){
        let opt = {
            obj:null,
            json:{},
            durtion:1000,
            cb:function(){},
            fx:'linear'
        }

        //有配置走配置，没配置走默认
        Object.assign(opt,opts);
        if(opts.cb && typeof opts.cb !== 'function'){
            opt.cb = function(){}
        }

        let f = opt.fx;
        //存储每个属性的初始值和目标点
        let j = {};
        // 枚举整个json,把每个属性赋值为对象，在对象下又有初始值和目标点
        for(let attr in opt.json){
            if(opt.json.hasOwnProperty(attr)){
                //获取到每个属性的初始值
                let b = parseFloat(getComputedStyle(opt.obj)[attr]);
                let c = 0;
                //获取到每个属性的目标点 类似于{width:{fx:'exx',d:500}}
                if(typeof opt.json[attr] === 'object'){
                    j[attr] = {b}
                    for(let attr2 in opt.json[attr]){
                        j[attr][attr2] = opt.json[attr][attr2];
                    }

                    j[attr].c = j[attr].c - j[attr].b;
                }else{
                    c = opt.json[attr];
                    c = c - b;
                    j[attr] = {
                        b,
                        c
                    };
                }
            }
        }
       
        let d = opt.durtion;
        let t = 0;

       
        (function move(){
            opt.obj.timer = requestAnimationFrame(move);
            t += 16.7;
            if(t >= d)t=d;

            for(let attr in j){
                //把默认值赋值给fx，不然都覆盖了
                opt.fx = f;
                opt.fx = j[attr].fx || opt.fx;
                //如果是opacity就不加单位
                if(attr === 'opacity'){
                    opt.obj.style[attr] = Tween[opt.fx](t, j[attr].b,j[attr].c, d);
                }else{
                    opt.obj.style[attr] = Tween[opt.fx](t, j[attr].b,j[attr].c, d) + 'px';
                }
            }
           
            if(t === d){
                cancelAnimationFrame(opt.obj.timer);
                opt.cb();
            }
        })();
    }

    return {
        getChild,
        addAttr,
        getParent,
        getParents,
        targetP,
        duang,
        getChildren,
        children,
        startMove
    }
})();