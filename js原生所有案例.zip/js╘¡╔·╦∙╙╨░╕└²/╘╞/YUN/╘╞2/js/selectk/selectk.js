let {duang} = myTools;//碰撞
let rv = false; //阻止默认行为的默认值
folders.addEventListener('mousedown',function(ev){ //应该在点到重命名的时候让它有默认行为，点到别的地方就让它没有默认行为。 
    ev.returnValue = rv;  //false阻止了，true就是没有阻止
    rv = false;
    if(targetP(ev.target,'file-item'))return;  //如果down的时候点中了文件夹，就不能让选框出来。当点中名为‘file-item’的div或者点中div里面的元素都不能画框
    let id = breadNav.getElementsByTagName('span')[0].dataset.id*1;
    let {left,top} = fBox.getBoundingClientRect();
    let fileItem = folders.getElementsByClassName('file-item');
    let arr = getChild(id);
   
    //点空白处，清除所有的选中
    for(let i=0;i<fileItem.length;i++){     
        if(arr && arr[i]){
            arr[i].checked = false; //在down的时候把所有的数据checked设置为false
            render(id);
        }
    }
    seleEleArr.length = 0; //为了保证每次选中的数据都是最新的
    let disX = ev.pageX - left;//存下一开始的位置
    let disY = ev.pageY - top;
    kuang.style.display = 'block';
    kuang.style.left = disX + 'px';
    kuang.style.top = disY + 'px';

    let move = function(ev){//在拖拽的时候，按下的点和移动的点比，哪边小left和top值就走哪边       
        let l = ev.pageX - disX;
        let t = ev.pageY - disY;
        seleEleArr.length = 0;  //每次move的时候都把数组清空，为了重新收集被碰撞的元素。
        kuang.style.width = Math.abs(l - left) + 'px';
        kuang.style.height = Math.abs(t - top) + 'px';
        for(let i=0,len = fileItem.length;i<len;i++){
            if(duang(kuang,fileItem[i])){
                fileItem[i].classList.add('active');
                fileItem[i].children[3].className = 'checked';
                seleEleArr.push(data[fileItem[i].dataset.id*1]);
                //log(seleEleArr)
                data[fileItem[i].dataset.id*1].checked = true;
            }else{
                fileItem[i].classList.remove('active');
                fileItem[i].children[3].className = '';
                data[fileItem[i].dataset.id*1].checked = false;
            }
        }
       // 如果碰撞元素的个数和页面中的文件夹个数相等，说明全选
        checkedAll.className = arr.every(e=>e.checked)?'checked':'';
        kuang.style.left = Math.min(disX,ev.pageX - left) + 'px';
        kuang.style.top = Math.min(disY,ev.pageY - top) + 'px';
    }   
    let up = function(){
        kuang.style.width = kuang.style.height = 0;
        kuang.style.display = 'none';      
        document.removeEventListener('mousemove',move);
        document.removeEventListener('mouseup',up);
    }
    document.addEventListener('mousemove',move);
    document.addEventListener('mouseup',up);   
});

