create.onclick = function () {//新建文件夹
    fEmpty.style.display = 'none';
    let div = document.createElement('div');
    div.className = 'file-item';
    let img = document.createElement('img');
    img.src = 'img/folder-b.png';
    let input = document.createElement('input');
    input.className = "editor";
    input.value = '新建文件夹'
    let is = document.createElement('i');

    div.append(img);
    div.append(input);
    div.append(is);

    folders.appendChild(div);
    input.style.display = 'block';
    input.select();
    input.onblur = function () {
        let v = this.value;
        let arr = getChild(globalId);
        //log(globalId);
        let cm = arr.some(e => e.title === v);
        let id = +new Date;
        if (!cm) {//解决重名问题
            data[id] = {
                title: v,
                id,
                pid: globalId,
                checked: false
            }
        } else {
            let v2 = v;
            let num = 0;
            while (cm) {
                v2 = v2.replace(/\(\d+\)/, '') + `(${++num})`;
                cm = arr.some(e => e.title === v2);
            }
            data[id] = {
                title: v2,
                id,
                pid: globalId,
                checked: false
            }
        }
        render(globalId);
        renderTree(0);
        fullbox('新建文件夹成功')
    }
}

