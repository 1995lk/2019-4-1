// del.onclick=function(){//删除功能
//     let arr = getChild(globalId);
//     let len = arr.filter(e=>e.checked).length//存储当前页面被选中的数据的个数
//     if(len){//选择了数据
//         tanbox.style.display='block'; 
//     }else{
//         fullbox('请选择要删除的文件')
//     }
//     sure.onclick=function(){
//         arr.forEach(e=>{
//             if(e.checked){
//                 delete data[e.id]
//             }
//         });
//         render(globalId);
//         tanbox.style.display='none'; 
//     }
//     qx.onclick=x.onclick=function(){
//         tanbox.style.display='none'; 
//     }
// }
del.onclick = function () {//删除功能
    let arr = getChild(globalId);
    arr = arr.filter(e => e.checked)
    let len = arr.length;
    tanbox.style.display = 'block';
    sure.onclick = function () {//点击确定的时候
        if (len) {//选择了数据
            arr.forEach(e => {
                delete data[e.id]
            })
            render(globalId);
            renderTree(0);
            tanbox.style.display = 'none';
        } else {
            fullbox('请选择要删除的文件')
        }
    }
    qx.onclick = x.onclick = function () {//点击取消的时候
        tanbox.style.display = 'none';
    }
}