$('#checkedAll').click(function(){
   let ary = getChild(globalId);
   let boolean=checkedAll.classList.toggle('checked')
   ary.forEach(ele => {
      ele.checked=boolean?true:false; 
   });
  render(globalId);
})