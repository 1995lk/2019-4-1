let { po, duang } = tools;
//let checkedNum = 0;
$('#fBox').mousedown(function (ev) {
    if (ev.target.classList.contains('file-item') || ev.target.parentNode.classList.contains('file-item')) {//在file-item上不能画框
        return false;
    }
    //点击空白处的时候，把所有的文件夹checked状态清除
    let ary = getChild(globalId);//获取当前页面的所有数据
    ary.forEach(item => item.checked = false);
    render(globalId);

    let { top } = po(fBox);
    let disX = ev.pageX - fBox.offsetLeft;
    let disY = ev.pageY - top;
    // log(ev.pageY);
    let kuang = document.createElement('div')
    kuang.className = 'kuang';
    fBox.appendChild(kuang);
    kuang.style.left = disX + 'px';
    kuang.style.top = disY + 'px';
    $('#fBox').mousemove(function (ev) {
        let w = Math.abs((ev.pageX - fBox.offsetLeft) - disX);
        let h = Math.abs((ev.pageY - top) - disY);

        kuang.style.width = w + 'px';
        kuang.style.height = h + 'px';

        let l = Math.min(disX, (ev.pageX - fBox.offsetLeft));
        let t = Math.min(disY, (ev.pageY - top));
        kuang.style.left = l + 'px';
        kuang.style.top = t + 'px';

        let fileItem = document.querySelectorAll('.file-item');

        fileItem.forEach((ele, i) => {
            if (duang(kuang, ele)) {
                data[ele.dataset.id].checked = true;
                //checkedNum ++;
            } else {
                data[ele.dataset.id].checked = false;
            }
        });
        // if(checkedNum === fileItem.length){
        //     checkedAll.className = 'checked';
        // }else{
        //     checkedAll.className = '';
        // }
        render(globalId);
        return false;
    })
    $('#body').mouseup(function () {
        kuang.style.display = 'none';
        kuang.style.width = kuang.style.height = 0;
        fBox.onmousemove = document.onmouseup = null;
    })
})