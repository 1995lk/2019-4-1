let { getParents } = tools;
function renderbreadNav() {//生成面包屑
    let html = '';
    let arr = getParents(globalId);
    arr.forEach((item, i, all) => {
        if (i != all.length - 1) {
             //用自定义的方式去存储每个标签的对应的id
            html += `<a data-id="${item.id}" href="javascript:;">${item.title}</a>`;
        } else {
            html += `<span>${item.title}</span>`;
        }
    });
    breadNav.innerHTML = html;
}
//点击面包屑的时候，把对应的Id获取出来，赋值全局的globalId
breadNav.onclick = function (ev) {//点击面包屑的时候
    if (ev.target.tagName === 'A') {//点击的是a标签
        let ary = getChild(globalId);
        ary.forEach(e => e.checked = false);
        render(ev.target.getAttribute('data-id'));
        renderbreadNav();
    }
}
renderbreadNav();