
//装文件夹容器的高度
folders.style.height = iH - headH - breadmenuH + 'px';
let globalId = 0;//存储id用的
//渲染页面
function render(id) {
    globalId = id * 1;
    folders.innerHTML = '';
    let ary = getChild(globalId);
    if (ary && ary.length != 0) {
        checkedAll.className = ary.every(e => e.checked) ? 'checked' : '';
        fEmpty.style.display = 'none';
        ary.forEach((ele, i) => {
            let div = document.createElement('div');
            div.className = ele.checked ? 'file-item active' : 'file-item';
            div.dataset.id = ele.id;
            let img = document.createElement('img');
            img.src = 'img/folder-b.png';
            img.ondblclick = function () {
                render(ele.id);
                renderbreadNav()
                ary.forEach(item => item.checked = false);
                checkedAll.className = '';
            }
            let span = document.createElement('span');
            span.className = 'folder-name';
            span.innerHTML = ele.title;

            let input = document.createElement('input');
            input.className = "editor";
            input.value = ele.title;
            let is = document.createElement('i');
            is.className = ele.checked ? 'checked' : '';
            is.onclick = function () {
                ele.checked = !ele.checked;
                render(id);
            }
            div.append(img);
            div.append(span);
            div.append(input);
            div.append(is);

            folders.appendChild(div);
        });
    } else {//点没了之后要显示暂无文件
        fEmpty.style.display = 'block';
        checkedAll.className = '';
    }
}
render(0);








