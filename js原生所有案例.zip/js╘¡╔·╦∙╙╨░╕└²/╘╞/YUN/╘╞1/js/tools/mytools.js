let tools = (function(){

    function po(ele){
        let obj = ele,
        top = 0,left = 0;
        while(obj){
            top += obj.offsetTop + obj.clientTop;
            left += obj.offsetLeft + obj.clientLeft;
            obj = obj.offsetParent;
        }
        top -= ele.clientTop;
        left -= ele.clientLeft;
        return {top,left}
    }
    function duang(obj,obj2){
        let l1 = obj.offsetLeft;
        let t1 = obj.offsetTop;
        let r1 = l1 + obj.offsetWidth;
        let b1 = t1 + obj.offsetHeight;

        let l2 = obj2.offsetLeft;
        let t2 = obj2.offsetTop;
        let r2 = l2 + obj2.offsetWidth;
        let b2 = t2 + obj2.offsetHeight;

        //只要碰到就返回true，否则false
        if(r1 < l2 || b1 < t2 || l1 > r2 || t1 > b2){
            return false;
        }else{
            return true;
        }
    }

        //循环所有的数据，把每个数据的pid和你传进来的pid对比，如果一致，说明
    //就放到一个数组中，这个数组就是同级的了
    function getChild(pid){
        //判断一下是否有这个pid，如果整个对象下都没有这个数据
        //返回null
        if(!data[pid])return null;
        let arr = [];
        for(let attr in data){
            if(data[attr].pid === pid){
                    arr.push(data[attr]);
            }
        }
        return arr;
    }

    function getParent(id){
        //有这个数据并且pid不等于-1

        if(!data[id] || data[id].pid ==-1)return null;
        return data[data[id].pid];

        // if(data[id] && data[id].pid != -1){//
        //     return data[data[id].pid];
        // }else{
        //     return null;
        // }
    }

    // 2.获取一堆的父级
    function getParents(id){
        let arr = [];
        let now = data[id];
        while(now){
            arr.unshift(now);
            now = getParent(now.id); 
        }
        return arr;
    }

    function startMove(opts){
        let opt = {
            obj:null,
            json:{},
            durtion:1000,
            cb:function(){},
            fx:'linear'
        }

        //有配置走配置，没配置走默认
        Object.assign(opt,opts);
        if(opts.cb && typeof opts.cb !== 'function'){
            opt.cb = function(){}
        }

        let f = opt.fx;
        //存储每个属性的初始值和目标点
        let j = {};
        // 枚举整个json,把每个属性赋值为对象，在对象下又有初始值和目标点
        for(let attr in opt.json){
            if(opt.json.hasOwnProperty(attr)){
                //获取到每个属性的初始值
                let b = parseFloat(getComputedStyle(opt.obj)[attr]);
                let c = 0;
                //获取到每个属性的目标点 类似于{width:{fx:'exx',d:500}}
                if(typeof opt.json[attr] === 'object'){
                    j[attr] = {b}
                    for(let attr2 in opt.json[attr]){
                        j[attr][attr2] = opt.json[attr][attr2];
                    }

                    j[attr].c = j[attr].c - j[attr].b;
                }else{
                    c = opt.json[attr];
                    c = c - b;
                    j[attr] = {
                        b,
                        c
                    };
                }
            }
        }
       
        let d = opt.durtion;
        let t = 0;

       
        (function move(){
            opt.obj.timer = requestAnimationFrame(move);
            t += 16.7;
            if(t >= d)t=d;

            for(let attr in j){
                //把默认值赋值给fx，不然都覆盖了
                opt.fx = f;
                opt.fx = j[attr].fx || opt.fx;
                //如果是opacity就不加单位
                if(attr === 'opacity'){
                    opt.obj.style[attr] = Tween[opt.fx](t, j[attr].b,j[attr].c, d);
                }else{
                    opt.obj.style[attr] = Tween[opt.fx](t, j[attr].b,j[attr].c, d) + 'px';
                }
            }
           
            if(t === d){
                cancelAnimationFrame(opt.obj.timer);
                opt.cb();
            }
        })();
    }
    return {    
        po,
        duang,
        getChild,
        getParent,
        getParents,
        startMove
    }
})();