checkedAll.onclick = function () {//全选
    //log(1)
    let boolean=checkedAll.classList.toggle('checked')
    let ary = getChild(globalId);
    ary.forEach(ele => {
       ele.checked=boolean?true:false; 
    });
   render(globalId);
}