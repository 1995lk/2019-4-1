let id = 0; //为了记录移动的id
let o = false; //判断是否为非法操作
remove.onclick = function(){
    let ary = getChild(globalId);
    let arr = ary.filter(item=>item.checked);
    let len = arr.length;
    if(len < 1){
        fullbox('请选择要移动的文件');
        return ;
    }

    modalTree.style.display = 'block';
    content.innerHTML = renderTree(0);

    content.onclick = function(ev){ //点击移动到的树形菜单中
        if(ev.target.tagName === 'SPAN'){
            o = false;//重新设置一次false
            let li = ev.target.parentNode.parentNode;
            let span = content.getElementsByTagName('span');
            //把所有的span的背景色清掉
            for(let i=0;i<span.length;i++){
                span[i].style.background = '';
            }        
            ev.target.style.background = '#ccc';//把当前的背景色加上
            id = li.dataset.id*1; //获取到移动到的id
            if(id){                
                if(arr.some(e=>e.id === id)){//移动到的id有没有和选中的id重名
                    fullbox('非法选择');
                    o = true;
                    return;
                }
                //生成ul
                if(!li.children[0].classList.contains('tree-ico-none')){
                    let o = !li.children[0].classList.toggle('close')
                    renderChild(li,id,o);
                }
            }
        }
    }
}
ok.onclick = function(){//点击确定   
    if(o){//刚才点击移动到的span时，是否有非法操作
        fullbox('非法选择');
        return;
    };
    //id 为点击的
    let ary = getChild(globalId);
    let arr = ary.filter(item=>item.checked);
    let len = arr.length;
    let onoff = false;
    if(len < 1 )return;

    if(onoff){//点击自己
        fullbox('非法操作,已报110');
    }else{
        arr.forEach(ele=>{
            ele.pid = id; 
            ele.checked = false;
        });
        render(globalId);
        renderTree(0);
    }
    modalTree.style.display = 'none';
}

cancel.onclick =iconClose.onclick= function(){//点击取消或者x的时候
    modalTree.style.display = 'none';
}