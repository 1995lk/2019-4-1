//全局的变量
let { log, dir } = console;
const folders = $('.folders')[0];
const breadNav = $('.bread-nav')[0];//存放面包屑的容器
const breadmenu = $('.breadmenu')[0];
const fEmpty = $('.f-empty')[0];//获取空页面的图片
const fullTipBox = $('.full-tip-box')[0];//新建文件夹成功的弹框
const kuang = $('.kuang')[0];//选框
const x = $('.close-ico')[0];//获取取消弹框的x
const sure =$('.conf-btn a')[0];//获取确定按钮
const qx =$('.conf-btn a')[1];//获取取消按钮
const treeMenu = $('.tree-menu ')[0];//获取放树的容器

const modalTree = $('.modal-tree')[0];
const content = $('.content')[0];
const ok =$('.modal-tree .ok')[0];
const cancel =$('.modal-tree .cancel')[0];
const iconClose=$('.icon_close')[0]

//装文件夹容器的高度的相关数据
const iH = window.innerHeight;
const headH = head.offsetHeight;
const breadmenuH = breadmenu.offsetHeight;

let { startMove,getChild} = tools;
function fullbox(val) {
    fullTipBox.innerHTML = `
    <span class="full-tip">
    <span class="inner">
        <span class="tip-text">${val}</span>
    </span>
    </span>`;
    startMove({
        obj: fullTipBox,
        json: {
            top: 0
        },
        durtion: 500,
        fx: 'bounceOut',
        cb() {
            setTimeout(() => {
                startMove({
                    obj: fullTipBox,
                    json: {
                        top: -40
                    },
                    durtion: 300
                })
            }, 1000);
        }
    });
}
